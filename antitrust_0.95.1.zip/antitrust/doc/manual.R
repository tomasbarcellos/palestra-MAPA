### R code from vignette source 'manual.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: manual.Rnw:48-51
###################################################
library(antitrust)
ps.options(pointsize=12)
options(width=60)


